﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MailKitNetSmtp
{
    internal sealed class ContractGuids
    {
        public const string ServerClass = "978557AF-0822-445E-8CFC-091A292E9EEA";
        public const string ServerInterface = "5BE9FA52-FBE7-4C5D-98FF-899BF92789F1";
    }
}
