NetCore 3.1 Class Library MailKitNetSmtp

Este el proyecto de Visual Studio 2022 con el que he creado la libreria que uso en el ejemplo de PowerBuilder pbMailKit para enviar e-mails desde PowerBuilder:

https://github.com/rasanfe/pbMailKit

Para estar al tanto de lo que publico puedes seguri mi blog:

https://rsrsystem.blogspot.com/
