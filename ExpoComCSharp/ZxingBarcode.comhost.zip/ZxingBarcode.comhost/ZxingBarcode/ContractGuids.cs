﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZxingBarcode
{
    internal sealed class ContractGuids
    {
        public const string ServerClass = "CFFFBF06-B06F-40E5-B94C-2BEFB31C63C4";
        public const string ServerInterface = "F7370586-0FED-4F0E-86E6-08C9C1ED4327";
    }

}
