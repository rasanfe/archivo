﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetPdfService
{
    internal sealed class ContractGuids
    {
        public const string ServerClass = "CCDBF8FC-E519-465E-8293-E0787B4ED336";
        public const string ServerInterface = "AA406F79-775A-4C31-9832-82B183BE1C9F";
    }

}
