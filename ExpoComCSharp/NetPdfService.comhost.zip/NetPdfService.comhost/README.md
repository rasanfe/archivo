NetCore 3.1 Class Library NetPdfService

Este el proyecto de Visual Studio 2022 con el que he creado la libreria que uso en el ejemplo de PowerBuilder Pbfsign de Firmas digitales en PDF:

https://github.com/rasanfe/pdfsign

Para estar al tanto de lo que publico puedes seguri mi blog:

https://rsrsystem.blogspot.com/
