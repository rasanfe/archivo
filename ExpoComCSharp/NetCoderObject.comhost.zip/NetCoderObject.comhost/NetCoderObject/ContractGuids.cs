﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetCoderObject
{
    internal sealed class ContractGuids
    {
        public const string ServerClass = "16BDED73-51A3-43FB-8DE5-95C86AA4CCDA";
        public const string ServerInterface = "4B554B69-F17F-40A1-AA93-711A8F0A02C6";
    }
}
