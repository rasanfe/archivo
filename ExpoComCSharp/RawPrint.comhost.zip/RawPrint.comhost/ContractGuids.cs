﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RawPrint
{
    internal sealed class ContractGuids
    {
        public const string ServerClass = "D8E5E57F-128B-4AC9-BAA7-50B1342B2098";
        public const string ServerInterface = "9B399926-C781-4814-B09C-F4E1D25D5A5C";
    }
}
