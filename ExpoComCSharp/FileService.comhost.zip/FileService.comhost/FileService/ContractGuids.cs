﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FileService
{
    internal sealed class ContractGuids
    {
        public const string ServerClass = "4CDF79F0-4520-4A23-ABAE-77F9E29DE6A1";
        public const string ServerInterface = "CEC45A05-5E64-4003-945E-54413F215B11";
    }
}
