﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SplitMergePdf
{
    internal sealed class ContractGuids
    {
        public const string ServerClass = "D920A2AB-F38A-4786-80C1-0E5D86C1F710";
        public const string ServerInterface = "F1608D54-75DD-4B48-9B89-B94E14BAE550";
    }

}
