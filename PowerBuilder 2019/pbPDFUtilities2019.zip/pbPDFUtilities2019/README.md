# pbpdfutilities
PowerBuilder Pdf Uitilities (Split & Merge)

Para finalizar el mes de Enero, hoy os traigo un pequeño ejemplo que sirve para unir dos PDF en un único PDF o para Dividirlo en un PDF por página.

Es muy posible que en futuras versiones de PowerBuilder integren esta funcionalidad como nativa, pero de momento hay que recurrir a aplicaciones de terceros.

También podéis ver un video demo en:

https://youtu.be/5yb0aYMcQoQ

Para estar al tanto de lo que publico puedes seguir mi blog:

https://rsrsystem.blogspot.com/


Si necesitas modificar el proyecto de Visual Studio 2022 lo tienes disponible aqui:

https://github.com/rasanfe/SplitMergePdf
