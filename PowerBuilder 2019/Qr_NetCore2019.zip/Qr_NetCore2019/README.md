# qrcode
PowerBuilder QrCode

Ejemplo PowerBUilder para Generar y Leer Códigos QR.

Si necesitas modificar el proyecto de Visual Studio 2022 lo tienes disponible aqui:

https://github.com/rasanfe/ZxingBarcode

Para que este ejemplo funcione hay que tener instalado Net Core 3.1.

Puedes descargarlo en:

https://dotnet.microsoft.com/en-us/download/dotnet/3.1

He creado un video demo en Youtube: 

https://youtu.be/rmw8BaNovJE

Para estar al tanto de lo que publico puedes seguir mi blog:

https://rsrsystem.blogspot.com/
