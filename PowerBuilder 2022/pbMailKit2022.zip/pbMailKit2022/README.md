# pbMailKit
Envío Correo SMTP con MailKit y PowerBuilder

Ejemplo para envíar correos electrónicos desde PowerBuilder.

Actualizado a Pb2022 Build 1716 (06-08-2022)

Si necesitas modificar el proyecto de Visual Studio 2022 lo tienes disponible aqui:

https://github.com/rasanfe/MailKitNetSmtp

Para estar al tanto de lo que publico puedes seguir mi blog:

https://rsrsystem.blogspot.com/
