# pbcolors
PowerBuilder Color Selector

Pequeña aplicación que a mi me ha sido muy últil para tener mis colores favoritos a mano y poderlos utilizar en aplicaciones PowerBuilder.

Pudes elegir el color que quieras y convertirlo entre anotación RGB, html y como número.

Para estar al tanto de lo que publico puedes seguri mi blog:

https://rsrsystem.blogspot.com/
