NetCore 3.1 Class Library ZxingBarcode

Este el proyecto de Visual Studio 2022 con el que he creado la libreria que uso en el ejemplo de PowerBuilder Qrcode para Crear y Leer códigos Qr.

https://github.com/rasanfe/qrcode

Para estar al tanto de lo que publico puedes seguri mi blog:

https://rsrsystem.blogspot.com/
