NetCore 3.1 Class Library RawPrint

Este el proyecto de Visual Studio 2022 con el que he creado la libreria que uso en el ejemplo de PowerBuilder pbRawPrint para el envío directo de PDFs a la impresora.

https://github.com/rasanfe/pbRawPrint

Para estar al tanto de lo que publico puedes seguri mi blog:

https://rsrsystem.blogspot.com/
