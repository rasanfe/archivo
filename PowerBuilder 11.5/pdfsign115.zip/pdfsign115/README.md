# pdfsign
Firma Digital de Pdf's en PowerBuilder.

Este ejemplo permite la firma visual y no visual de documento pdf con certificado digital.

Para estar al tanto de lo que publico puedes seguir mi blog:

https://rsrsystem.blogspot.com/
