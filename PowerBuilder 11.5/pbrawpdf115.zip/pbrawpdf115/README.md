PowerBuilder pbRawPrint

Ejemplo PowerBUilder para Enviar archivos Directamente a la impresora.

Para que este ejemplo funcione hay que tener instalado Net Core 3.1.

Puedes descargarlo en:

https://dotnet.microsoft.com/en-us/download/dotnet/3.1

Para estar al tanto de lo que publico puedes seguir mi blog:

https://rsrsystem.blogspot.com/

Gracias a Frogmore Computer Services Ltd que es el autor original deñ Proyecto RawPrint:

https://github.com/frogmorecs/RawPrint
