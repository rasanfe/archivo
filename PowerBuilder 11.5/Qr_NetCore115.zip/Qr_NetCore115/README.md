# qrcode
PowerBuilder QrCode

Ejemplo PowerBUilder para Generar y Leer Códigos QR.


Para que este ejemplo funcione hay que tener instalado Net Core 3.1.


Para estar al tanto de lo que publico puedes seguir mi blog:

https://rsrsystem.blogspot.com/
