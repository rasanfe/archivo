# qrcode
PowerBuilder Ean13Code

PowerBuilder Example to Generate and Read Ean13 Codes.

For this example to work you must have installed Net Core 3.1.

You can download it at:

https://dotnet.microsoft.com/en-us/download/dotnet/3.1

To be aware of what I publish you can follow my blog:

https://rsrsystem.blogspot.com/
