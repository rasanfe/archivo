# pbfileservice
PowerBuilder FileService (C# System.IO)

Ejemplo de como Integrar la Clase System.IO.Path en PowerBuilder que trae funciones muy útiles para manejar nombres de ficheros.

Para estar al tanto de lo que publico puedes seguir mi blog:

https://rsrsystem.blogspot.com/

