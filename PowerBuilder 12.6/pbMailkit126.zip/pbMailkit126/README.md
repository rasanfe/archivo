# pbMailKit
Envío Correo SMTP con MailKit y PowerBuilder

Ejemplo para envíar correos electrónicos desde PowerBuilder.

Para estar al tanto de lo que publico puedes seguir mi blog:

https://rsrsystem.blogspot.com/
