# app_secdata
Protección de datos en PowerBuilder.
Inspirado en el ejemplo de Dora Sistemas de su canal de youtube (https://youtu.be/MbuxTZYqmvM)
Inntentamos traer nuevas funcionalidades a PowerBuilder 12.6.
Agradecimiento a Topwiz Software por su Ejemplo Cryptoapi (https://www.topwizprogramming.com/freecode_cryptoapi.html)

Encoder     -------->
Encrypting  --------> Con los nuevos mi objeto nvo_coderobject y el de Topwiz n_cryptoapi
Hashing     -------->

Para estar al tanto de lo que publico puedes seguir mi blog:

https://rsrsystem.blogspot.com/
