# app_secdata
Protección nativa de datos en PowerBuilder.
Desarrolo del ejemplo de Dora Sistemas de su canal de youtube (https://youtu.be/MbuxTZYqmvM)

Encoder     -------->
Encrypting  --------> Con los nuevos objetos coderobject y crypterobeect de PowerBuilder
Hashing     -------->

Para estar al tanto de lo que publico puedes seguir mi blog:

https://rsrsystem.blogspot.com/
