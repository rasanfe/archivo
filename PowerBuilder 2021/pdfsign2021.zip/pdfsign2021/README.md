# pdfsign
Firma Digital de Pdf's en PowerBuilder.

Este ejemplo permite la firma visual y no visual de documento pdf con certificado digital.

Si necesitas modificar el proyecto de Visual Studio 2022 lo tienes disponible aqui:

https://github.com/rasanfe/NetPdfService

Para estar al tanto de lo que publico puedes seguir mi blog:

https://rsrsystem.blogspot.com/
